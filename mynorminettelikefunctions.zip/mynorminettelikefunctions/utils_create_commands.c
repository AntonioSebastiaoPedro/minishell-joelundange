/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_create_commands.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/25 10:48:15 by llundage          #+#    #+#             */
/*   Updated: 2025/04/25 10:48:42 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

void	free_command_args(t_main *main, int i)
{
	while (i >= 0)
		free(main->commands[i--].av);
	free(main->commands);
}

t_tokens	*skip_pipe_tokens(t_tokens *tmp)
{
	if (tmp && tmp->string[0] == '|' && tmp->type == 0)
		tmp = tmp->next;
	return (tmp);
}

int	set_command_args(t_tokens *tmp, t_main *main, int i)
{
	main->commands[i].ac = ft_count_ac(tmp);
	main->commands[i].av = set_av(tmp, &main->commands[i], main, 0);
	if (main->commands[i].av == NULL)
	{
		free_command_args(main, i);
		return (0);
	}
	main->commands[i].next = NULL;
	if (i > 0)
		main->commands[i - 1].next = &main->commands[i];
	return (1);
}
