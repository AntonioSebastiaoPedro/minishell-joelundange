/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   execute_binary.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 09:26:21 by llundage          #+#    #+#             */
/*   Updated: 2025/04/24 21:37:48 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

void	ft_relative_path(t_command *command)
{
	extern char	**environ;

	if (execve(command->av[0], command->av, environ) == -1)
		printf("minishell: %s: %s\n", command->av[0], strerror(errno));
}

void	ft_absolute_path(t_command *command)
{
	extern char	**environ;

	if (execve(command->av[0], command->av, environ) == -1)
		printf("minishell: %s: %s\n", command->av[0], strerror(errno));
}

int	report_error(t_main *main, t_command *command, char **paths)
{
	if (!paths)
	{
		fprintf(stderr, "minishell$: %s: No such file or directory\n",
			command->av[0]);
		main->status = 127;
		return (1);
	}
	return (0);
}
