/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   redirects.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 08:59:02 by llundage          #+#    #+#             */
/*   Updated: 2025/04/24 09:20:59 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

void	ft_execute(t_main *main, t_command *command)
{
	if (ft_is_builtin((*command).av[0]))
		main->status = ft_execute_builtins(*command);
	else
	{
		ft_execute_binary(main, command);
	}
}

void	start_execution(t_main *main)
{
	int	i;

	i = 0;
	while (main->commands && i < main->qtd_commands)
	{
		ft_execute(main, &main->commands[i]);
		i++;
	}
}
