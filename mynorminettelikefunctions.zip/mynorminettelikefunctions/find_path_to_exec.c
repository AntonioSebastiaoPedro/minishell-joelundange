/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   find_path_to_exec.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/25 16:40:10 by llundage          #+#    #+#             */
/*   Updated: 2025/04/25 17:10:00 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

char	**get_command_paths(void)
{
	char	*path_env;

	path_env = getenv("PATH");
	if (!path_env)
		return (NULL);
	return (ft_split(path_env, ':'));
}

char	*build_full_path(const char *dir, const char *cmd)
{
	char	*tmp;
	char	*full;

	tmp = ft_strjoin(dir, "/");
	if (!tmp)
		return (NULL);
	full = ft_strjoin(tmp, cmd);
	free(tmp);
	return (full);
}

int	try_exec_path(const char *full_path, t_command *command)
{
	extern char	**environ;

	if (access(full_path, X_OK) == 0)
	{
		execve(full_path, command->av, environ);
		fprintf(stderr, "minishell: %s: %s\n", command->av[0], strerror(errno));
		return (-1);
	}
	return (0);
}

void	ft_free_split_and_status(t_main *main, char	**paths, int status)
{
	ft_free_split(paths);
	main->status = status;
}

void	ft_path(t_main *main, t_command *command, int i)
{
	char	**paths;
	char	*full_path;

	paths = get_command_paths();
	if (report_error(main, command, paths))
		return ;
	while (paths[++i])
	{
		full_path = build_full_path(paths[i], command->av[0]);
		if (!full_path)
		{
			fprintf(stderr, "minishell: memory allocation error\n");
			ft_free_split_and_status(main, paths, 1);
			return ;
		}
		if (try_exec_path(full_path, command) == -1)
		{
			free(full_path);
			ft_free_split_and_status(main, paths, 126);
			return ;
		}
		free(full_path);
	}
	fprintf(stderr, "minishell$: %s: command not found\n", command->av[0]);
	ft_free_split_and_status(main, paths, 127);
}
