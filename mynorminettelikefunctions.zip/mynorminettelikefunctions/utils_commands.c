/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_commands.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 02:53:53 by llundage          #+#    #+#             */
/*   Updated: 2025/04/24 03:12:05 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

int	ft_count_ac(t_tokens *tokens)
{
	int			ac;
	t_tokens	*aux;

	ac = 0;
	aux = tokens;
	while (aux != NULL)
	{
		if (aux->string[0] == '|' && aux->type == 0)
			break ;
		ac++;
		aux = aux->next;
	}
	return (ac);
}

int	ft_count_command(t_main *main, t_tokens *tokens)
{
	t_tokens	*aux;
	int			qtd_commands;

	(void)main;
	aux = tokens;
	qtd_commands = 0;
	while (aux != NULL)
	{
		if (aux->string && aux->string[0] == '|' && aux->type == 0)
			qtd_commands++;
		aux = aux->next;
	}
	return (qtd_commands);
}

int	isctrlop(char c)
{
	if (c == '<' || c == '|' || c == '>')
		return (1);
	return (0);
}

void	ft_create_pipe(t_command *commands, int pipes, int *status)
{
	int	i;

	i = 0;
	while (i < pipes)
	{
		if (pipe(commands[i].fd) == -1)
		{
			printf("Error: funcao pipe");
			*status = 1;
			exit(1);
		}
		printf("command[%d]->read=%d|wite=%d\n", i,
			commands[i].fd[0], commands[i].fd[1]);
		i++;
	}
}

void	ft_set_commands(t_main *main)
{
	int	i;

	i = 0;
	while (i < main->qtd_commands)
	{
		main->commands[i].ac = 0;
		main->commands[i].av = NULL;
		main->commands[i].read_from = -42;
		main->commands[i].write_to = -42;
		main->commands[i].fd[0] = -1;
		main->commands[i].fd[1] = -1;
		i++;
	}
}
