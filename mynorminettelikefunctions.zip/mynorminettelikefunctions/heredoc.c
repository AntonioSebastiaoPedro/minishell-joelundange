/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   heredoc.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/25 09:38:25 by llundage          #+#    #+#             */
/*   Updated: 2025/04/25 09:38:46 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

void	handle_heredoc(int pipefd[2], t_command *cmd,
	char *delimiter, int *status)
{
	pid_t	pid;

	pipe(pipefd);
	cmd->read_from = dup(pipefd[0]);
	pid = fork();
	if (pid == -1)
	{
		printf("Error: %s\n", strerror(errno));
		exit(EXIT_FAILURE);
	}
	if (pid == 0)
		heredoc_child(pipefd[1], delimiter);
	waitpid(pid, status, 0);
	close(pipefd[1]);
	close(pipefd[0]);
}

void	heredoc_child(int write_fd, char *delimiter)
{
	char	*input;

	while (1)
	{
		input = readline(">");
		if (!input)
			break ;
		if (ft_strcmp(input, delimiter) == 0)
		{
			free(input);
			break ;
		}
		write(write_fd, input, ft_strlen(input));
		write(write_fd, "\n", 1);
		free(input);
	}
	exit(EXIT_SUCCESS);
}
