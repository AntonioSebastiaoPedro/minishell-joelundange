/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   create_commands.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 15:24:32 by llundage          #+#    #+#             */
/*   Updated: 2025/04/25 09:46:05 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

int	set_to_redir(t_tokens *tokens, t_command *cmd, int *status)
{
	int		pipehere[2];
	char	*delimiter;

	if (!tokens || !tokens->string || tokens->type != 0)
		return (0);
	if (is_out_redir(tokens))
		cmd->write_to = open(tokens->next->string,
				O_CREAT | O_WRONLY | O_TRUNC, 0644);
	else if (is_append_redir(tokens))
		cmd->write_to = open(tokens->next->string,
				O_CREAT | O_WRONLY | O_APPEND, 0644);
	else if (is_in_redir(tokens))
		cmd->read_from = open(tokens->next->string, O_RDONLY, 0644);
	else if (is_heredoc(tokens))
	{
		delimiter = tokens->next->string;
		handle_heredoc(pipehere, cmd, delimiter, status);
	}
	return (check_redir_errors(cmd, status));
}

char	**set_av(t_tokens *tokens, t_command *command, t_main *main, int i)
{
	char		**av;
	t_tokens	*aux;

	aux = tokens;
	av = (char **)malloc(sizeof(char *) * (command->ac + 1));
	if (!av)
		return (NULL);
	while (aux != NULL && aux->string != NULL
		&& !(aux->string[0] == '|' && aux->type == 0))
	{
		if ((!strcmp(aux->string, ">") || !strcmp(aux->string, "<")
				|| !strcmp(aux->string, ">>")
				|| !strcmp(aux->string, "<<")) && aux->type == 0)
		{
			if (set_to_redir(aux, command, &main->status))
				return (free(av), NULL);
			aux = aux->next;
		}
		else
			av[i++] = aux->string;
		aux = aux->next;
	}
	av[i] = NULL;
	return (av);
}

t_command	*ft_create_commands(t_main *main, int i)
{
	t_tokens	*tmp;

	tmp = main->tokens;
	main->commands = (t_command *)malloc(sizeof(t_command)
			* main->qtd_commands);
	if (!main->commands)
		return (NULL);
	ft_set_commands(main);
	if (main->qtd_commands > 1)
		ft_create_pipe(main->commands, (main->qtd_commands - 1), &main->status);
	while (++i < main->qtd_commands)
	{
		if (!set_command_args(tmp, main, i))
			return (NULL);
		tmp = skip_pipe_tokens(tmp);
	}
	return (main->commands);
}
