/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils_builtins_2.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llundage <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/24 08:53:35 by llundage          #+#    #+#             */
/*   Updated: 2025/04/25 09:47:07 by llundage         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "main.h"

bool	ft_is_builtin(char *command)
{
	int		i;
	char	*builtins[7];

	builtins[0] = "echo";
	builtins[1] = "cd";
	builtins[2] = "pwd";
	builtins[3] = "export";
	builtins[4] = "unset";
	builtins[5] = "env";
	builtins[6] = "exit";
	i = 0;
	while (i < 7)
	{
		if (ft_strcmp(command, builtins[i++]) == 0)
			return (true);
	}
	return (false);
}

int	ft_execute_builtins(t_command command)
{
	int	retorno;

	retorno = 0;
	if (ft_strcmp(command.av[0], "echo") == 0)
		ft_echo(command);
	else if (ft_strcmp(command.av[0], "cd") == 0)
		retorno = ft_cd(command.av);
	else if (ft_strcmp(command.av[0], "pwd") == 0)
		retorno = ft_pwd();
	else if (ft_strcmp(command.av[0], "export") == 0)
		retorno = ft_export(command);
	else if (ft_strcmp(command.av[0], "unset") == 0)
		ft_unset(command);
	else if (ft_strcmp(command.av[0], "env") == 0)
		ft_env(command.av);
	else if (ft_strcmp(command.av[0], "exit") == 0)
		retorno = ft_exit(command);
	return (retorno);
}

char	is_validexit(char *strnbr)
{
	int	i;

	i = 0;
	if (*strnbr == '+' || *strnbr == '-')
		strnbr++;
	while (ft_isdigit(strnbr[i]))
		i++;
	return ((strnbr[i] == '\0') && (i > 0));
}

int	ft_exit(t_command command)
{
	if (command.ac == 1)
	{
		printf("%s\n", command.av[0]);
		exit(0);
	}
	else
	{
		if (!is_validexit(command.av[1]))
		{
			printf("exit\nminishell: %s: %s: numeric argument required\n",
				command.av[0], command.av[1]);
			exit(2);
		}
		if (command.ac > 2)
		{
			printf("%s\nminishell: %s: too many arguments\n",
				command.av[0], command.av[0]);
			return (1);
		}
		printf("%s\n", command.av[0]);
		exit(ft_atoi(command.av[1]));
	}
}
